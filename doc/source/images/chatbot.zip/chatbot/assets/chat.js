(function() {
  'use strict';
  // ----------------------------------------------------
  // Chat Details
  // ----------------------------------------------------

  // ----------------------------------------------------
  // Targeted Elements
  // ----------------------------------------------------

  const chatPage = $(document);
  const chatWindow = $('.chatbubble');
  const chatHeader = chatWindow.find('.unexpanded');
  const chatBody = chatWindow.find('.chat-window');

  // ----------------------------------------------------
  // Helpers
  // ----------------------------------------------------

  let helpers = {
    /**
     * Toggles the display of the chat window.
     */
    ToggleChatWindow: function() {
      chatWindow.toggleClass('opened');
      chatHeader
        .find('.title')
        .text(
          chatWindow.hasClass('opened')
            ? 'Click here to minimize assistant'
            : 'Click here to summon assistant'
        );
    },

    /**
     * Show the appropriate display screen. Login screen
     * or Chat screen.
     */
    ShowAppropriateChatDisplay: function() {
      helpers.ShowChatRoomDisplay()  
    },

    /**
     * Show the chat room messages dislay.
     */
    ShowChatRoomDisplay: function() {
      chatBody.find('.chats').addClass('active');
      chatBody.find('.loader-wrapper').hide();
      chatBody.find('.input, .messages').show();
    },

    /**
     * Append a message to the chat messages UI.
     */
    NewChatMessage: function(message) {
      if (chat.messages[message.id] === undefined) {
        const messageClass =
          message.sender.id !== chat.userId ? 'support' : 'user';

        chatBody.find('ul.messages').append(
          `<li class="clearfix message ${messageClass}">
                        <div class="sender">${message.sender.name}</div>
                        <div class="message">${message.text}</div>
                    </li>`
        );

        chat.messages[message.id] = message;

        chatBody.scrollTop(chatBody[0].scrollHeight);
      }
    },

    /**
     * Send a message to the chat channel
     */
    SendMessageToSupport: function(evt) {
      evt.preventDefault();

      const message = $('#newMessage')
        .val()
        .trim();

      chat.currentUser.sendMessage(
        { text: message, roomId: chat.room.id },
        msgId => {
          console.log('Message added!');
        },
        error => {
          console.log(`Error adding message to ${chat.room.id}: ${error}`);
        }
      );

      $('#newMessage').val('');
    },
  };

  // ----------------------------------------------------
  // Register page event listeners
  // ----------------------------------------------------

  chatPage.ready(helpers.ShowAppropriateChatDisplay);
  chatHeader.on('click', helpers.ToggleChatWindow);
  chatBody.find('#messageSupport').on('submit', helpers.SendMessageToSupport);

  $(document).ready(function() {
    $('#btnSubmit').click(function () {
      var requestData = $('#newMessage').val();
      if (requestData != ""){
        chatBody.find('ul.messages').append(
          `<li class="clearfix message support">
                        <div class="sender">Customer</div>
                        <div class="message">${requestData}</div>
                    </li>`
          );
          chatBody.find('#newMessage').val("");
          chatBody.scrollTop(chatBody[0].scrollHeight);
          // chatBody.find('.loader-wrapper').show();
        $.ajax({
          url:'http://localhost:8080/test',
          method:'get',
          data: {msg: requestData},
          dataType: 'json',
          success: function(data){
            chatBody.find('ul.messages').append(
              `<li class="clearfix message user">
                            <div class="sender">Assistant</div>
                            <div class="message">${data}</div>
                        </li>`
              );
            chatBody.scrollTop(chatBody[0].scrollHeight);
            // chatBody.find('.loader-wrapper').hide();
          }

        });
      }
    });
  });
})();
