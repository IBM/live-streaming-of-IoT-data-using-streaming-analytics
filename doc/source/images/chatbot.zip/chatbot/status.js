var NaturalLanguageClassifierV1 = require('watson-developer-cloud/natural-language-classifier/v1');
var fs = require('fs');

var naturalLanguageClassifier = new NaturalLanguageClassifierV1({
    iam_apikey: '-NmaxpRaLW95HVDcJiKTyPbiI6cE1PWZMW7RdNCFtvy3',
    url: 'https://gateway-fra.watsonplatform.net/natural-language-classifier/api'
  });

naturalLanguageClassifier.getClassifier({
  classifier_id: '2a2e30x428-nlc-131' },
  function(err, response) {
    if (err) {
      console.log('error:', err);
    } else {
      console.log(JSON.stringify(response, null, 2));
    }
});