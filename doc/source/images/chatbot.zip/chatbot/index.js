require('dotenv').config({
    silent: true
  });
var express = require("express");
var bodyParser = require("body-parser");
var path = require('path');
var cors = require('cors');
var viewsDir = path.join(__dirname);

var app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.text());
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

app.use(express.static(viewsDir));
app.use(express.static(path.join(__dirname, '/views')));
app.use(express.static(path.join(__dirname, '/public')));

var count = 2;
var AssistantV1 = require('ibm-watson/assistant/v1');

var assistant = new AssistantV1({
  iam_apikey: "JzHklO5kVxTHLj2eOdf2zemPabRJParUHDnI9UOFHbFP",
  url: "https://gateway-lon.watsonplatform.net/assistant/api",
  version: '2018-02-16'
});

var server = app.listen(8080, function () {
    console.log("app running on: http://localhost:8080");
});

app.get('/', (req,res) => {
    res.sendFile(path.join(viewsDir, '/views/index.html'));
});

app.get('/test', (req,res) => {
    var msg = req.query.msg;
    if (msg == "Is Sapiens book available?" && count!=0){
        assistant.message(
            {
              input: { text: "In stock?" },
              workspace_id: "92af6c6c-2ef0-4919-9957-73edcb08e5c8"
            })
            .then(result => {
              console.log(JSON.stringify(result, null, 2));
              answer = JSON.stringify(result, null, 2);
              fin= JSON.parse(answer);

              return res.json(fin.output.text[0]);
            })
            .catch(err => {
              console.log(err);
              return res.json(err);
            });
    }
    if (msg == "buy"){
        assistant.message(
            {
              input: { text: "123" },
              workspace_id: "92af6c6c-2ef0-4919-9957-73edcb08e5c8"
            })
            .then(result => {
              console.log(JSON.stringify(result, null, 2));
              count --;
              answer = JSON.stringify(result, null, 2);
              fin= JSON.parse(answer);

              return res.json(fin.output.text[0]);
            })
            .catch(err => {
              console.log(err);
              return res.json(err);
            });
    }
    if (msg == "Is Sapiens book available?" && count==0){
        assistant.message(
            {
              input: { text: "oops!" },
              workspace_id: "92af6c6c-2ef0-4919-9957-73edcb08e5c8"
            })
            .then(result => {
              console.log(JSON.stringify(result, null, 2));
              answer = JSON.stringify(result, null, 2);
              fin= JSON.parse(answer);

              return res.json(fin.output.text[0]);
            })
            .catch(err => {
              console.log(err);
              return res.json(err);
            });
    }
    
});

app.get('/test2', (req,res) => {
    var msg = req.query.msg;
    payload = {
        message: "Reply From API: "+msg
    };
    return res.json(payload);
});

function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  }

function isPrime( n ) {
    var max = Math.sqrt(n);
    for( var i = 2;  i <= max;  i++ ) {
        if( n % i === 0 )
            return false;
    }
    return true;
}
app.get('/test3', (req,res) => {
    
    var myno = getRandomInt(30);
    var primetrue = false;

    if(isPrime(myno)) {
        primetrue = true;
    }
    
    payload = {
        my_rand_no: myno,
        prime_no: primetrue
    };

    return res.json(payload);
});